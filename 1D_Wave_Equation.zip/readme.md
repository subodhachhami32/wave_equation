# 1D Wave Equation

## Running the simulation
1. Clone the repo

2. Open your terminal in the cloned directory and move into the sim directory.
```sh
cd sim
```
3. Start the local server.
  - If you have python installed on your machine
 ``` sh
 python -m http.server
 ```